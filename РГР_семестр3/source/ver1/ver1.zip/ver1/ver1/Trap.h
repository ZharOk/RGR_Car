
#if !defined(__UMLClassDiagram_1_Trap_h)
#define __UMLClassDiagram_1_Trap_h

///@brief Class Trap.
class Trap
{
public:
	///@brief Time of Trap.
	float TrapTime();
	///@brief Change speed 
    void changeSpeed(int maxSpeed);
	///@brief Get current speed.
	float getCurrSpeed(void);
	///@brief Trap Lenght.
	void incrTrapLength(int length);
	///@brief Get Trap Length.
	int getTrapLength();
	///@brief Set Trap Time.
	void setTrapTime(int someTime);
	///@brief Set Speed.
	void setSpeed(int speed);
	
protected:
private:
   friend float TrapTime(Trap &);
   float currSpeed;
   int TrapLength;
   float timeSpent;
   friend void setSpeed(int speed, Trap & );

};

#endif
