

#include "Timer.h"
#include <time.h>
#include<stdlib.h>
#include <iostream>
using namespace std;

void Timer::increaseTimer(void)
{

}
int Timer::getTime(void)
{
	return 0;
}

void Timer::stopTimer(void)
{
   
}
