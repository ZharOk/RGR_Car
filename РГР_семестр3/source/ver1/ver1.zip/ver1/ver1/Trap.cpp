

#include "Roads.h"
#include "Timer.h"
#include "Trap.h"
#include <iostream>
using namespace std;



float Trap::TrapTime()
{
	return 0;
}

void Trap::setTrapTime(int someTime)
{
	
}
float Trap::getCurrSpeed(void)
{
	return 0;
}

float TrapTime(Trap& Trap)
{
	return 0;
}

void Trap::incrTrapLength(int length)
{
	
}

int Trap::getTrapLength()
{
	return 0;
	
}

void Trap::setSpeed(int speed)
{
		
}


void Trap::changeSpeed(int maxSpeed)
{
	
}

void setSpeed(int speed, Trap &Trap)
{
	
}