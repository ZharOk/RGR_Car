

#include "Car.h"
#include "Roads.h"
#include<time.h>
#include<stdlib.h>

 
bool Roads::crash(int level)
{
	return 0;

}

int Roads::getSpeedLimit()
{
	return speedLimit;
}

int Roads::defineCrashLevel(int currSpeed)
{
	return 0;

}



void Roads::changeSpeedLimit(void)
{
	
}
