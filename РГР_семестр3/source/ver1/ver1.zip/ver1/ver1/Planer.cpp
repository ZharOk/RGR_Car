

#include "Trap.h"
#include "Planer.h"
#include "Roads.h"
#include "Timer.h"
#include "Car.h"
#include <time.h>
#include<stdlib.h>
#include <iostream>
#include <conio.h>
#include <string>
#include <Windows.h>
#include "PossibleObstacle.h"
using namespace std;

#define ESC 27


void Planer::start(void)
{

}

inline void Planer::chekCarStatus()
{
	
}

void Planer::mainPlaner()
{	
	
}


void Planer::finish(void)
{

}