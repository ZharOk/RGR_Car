

#include "PossibleObstacle.h"
#include <time.h>
#include<stdlib.h>
#include <iostream>


void PossibleObstacle::defineObstacle(void)		//TODO: define number of obstacle types  
{	

}


int PossibleObstacle::getObstacleType(void)
{
 return 0;
}
