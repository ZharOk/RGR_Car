
#include "Car.h"
#include <time.h>
#include<stdlib.h>


int Car::getGasolineStatus(void)
{
	return 0;
}


void Car::setGasolineStatus(int GasolineAmount)
{
   // TODO : implement
}



int Car::getCarStatus(void)
{
	return 0;
}

void Car::setCarStatus(int Status)
{

}



bool Car::isSummerTiers(void)
{
	return 0;
}


int Car::chooseGasolineNeed(void)
{	
 return 0;
}



void Car::changeGasolineStatus(int GasolineAmount, int key)
{

}
int Car::canMove()
{
  return 0;
}
int Car::getRepairCost()
{
	return 0;
}
int Car::getGasCost()
{
	return 0;
}
int Car::getMaxSpeed()
{
	return 0;
}
int Car::consumpedGasoline(int SomeDist)
{
	return 0;
	
}
