

#include "Tour.h"
#include "Planer.h"
#include "Roads.h"
#include "Timer.h"
#include "Car.h"
#include <time.h>
#include<stdlib.h>
#include <iostream>
#include <conio.h>
#include <string>
#include <Windows.h>
#include "PossibleObstacle.h"
using namespace std;

#define ESC 27

Planer::Planer(Roads* someRoad, Timer* someTimer): Tour()
{

	cout << "Planer was created" << endl;	
}

Planer::~Planer()
{
	cout << "Planer was destroyed" << endl;
}

void Planer::start(void)
{

}

inline void Planer::chekCarStatus()
{
	
}

void Planer::mainPlaner()
{	
	
}


void Planer::finish(void)
{

}