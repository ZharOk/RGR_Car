

#include "PossibleObstacle.h"
#include <time.h>
#include<stdlib.h>
#include <iostream>

PossibleObstacle::PossibleObstacle()
	:	obstacleType(0)
{
	std::cout << "Car was created (default)\n";
}

PossibleObstacle::PossibleObstacle(int n)
	:	obstacleType(n)
{
	std::cout << "Car was created (default)\n";
}

PossibleObstacle::~PossibleObstacle()
{
		std::cout << "PossibleObstacle destroyed \n";
}

void PossibleObstacle::defineObstacle(void)		//TODO: define number of obstacle types  
{	

}


int PossibleObstacle::getObstacleType(void)
{
 return 0;
}
