

#include "Roads.h"
#include "Timer.h"
#include "Tour.h"
#include <iostream>
using namespace std;

Tour::Tour()
{

	cout << "Tour was created" << endl;
}

Tour::~Tour()
{
	
	cout << "Tour was destroyed" << endl;	
}


float Tour::TourTime()
{
	return 0;
}

void Tour::setTourTime(int someTime)
{
	
}
float Tour::getCurrSpeed(void)
{
	return 0;
}

float TourTime(Tour& Tour)
{
	return 0;
}

void Tour::incrTourLength(int length)
{
	
}

int Tour::getTourLength()
{
	return 0;
	
}

void Tour::setSpeed(int speed)
{
		
}


void Tour::changeSpeed(int maxSpeed)
{
	
}

void setSpeed(int speed, Tour &Tour)
{
	
}