
#include "Car.h"
#include <time.h>
#include<stdlib.h>

Car::Car(int n)	// if n==1 enter values; if n==2 generate randomly
	: carStatus(n)
{	
	cout << "Car was created (initialisation)" << endl;
}

Car::Car()
	: carStatus(0)
{
	cout << "Car was created (default)" << endl;
}
Car::Car(const Car& CarCopy)
{
	GasolineStatus = CarCopy.GasolineStatus;
	carStatus = CarCopy.carStatus;
	areSummerTiers = CarCopy.areSummerTiers;
    GasolineConsumption = CarCopy.GasolineConsumption;
	GasolineNeed = CarCopy.GasolineNeed;
    repairCost = CarCopy.repairCost;
    repairLevel = CarCopy.repairLevel;
    gasCost = CarCopy.repairLevel;
	cout << "Car was created (copy)" << endl;
}

Car::~Car()
{
	cout << "Car was destroyed" << endl;
}

int Car::getGasolineStatus(void)
{
	return 0;
}


void Car::setGasolineStatus(int GasolineAmount)
{
   // TODO : implement
}



int Car::getCarStatus(void)
{
	return 0;
}

void Car::setCarStatus(int Status)
{

}



bool Car::isSummerTiers(void)
{
	return 0;
}


int Car::chooseGasolineNeed(void)
{	
 return 0;
}



void Car::changeGasolineStatus(int GasolineAmount, int key)
{

}
int Car::canMove()
{
  return 0;
}
int Car::getRepairCost()
{
	return 0;
}
int Car::getGasCost()
{
	return 0;
}
int Car::getMaxSpeed()
{
	return 0;
}
int Car::consumpedGasoline(int SomeDist)
{
	return 0;
	
}
