

#include "Timer.h"
#include <time.h>
#include<stdlib.h>
#include <iostream>
using namespace std;

Timer::Timer()
{
	cout << "Timer created"<< endl;
}

Timer::~Timer()
{
	cout << "timer destroyed\n";
}
void Timer::increaseTimer(void)
{

}
int Timer::getTime(void)
{
	return 0;
}

void Timer::stopTimer(void)
{
   
}
