

#include "Car.h"
#include "Roads.h"
#include<time.h>
#include<stdlib.h>

   
Roads::Roads()
{
	
	
		
	cout << "Road was created" << endl;
	
}

Roads::~Roads()
{
	//delete []car;
	cout << "Road was destroyed" << endl;
}
   
bool Roads::crash(int level)
{
	return 0;

}

int Roads::getSpeedLimit()
{
	return speedLimit;
}

int Roads::defineCrashLevel(int currSpeed)
{
	return 0;

}



void Roads::changeSpeedLimit(void)
{
	
}
