
#include "TransHelp.h"
#include <time.h>
#include<stdlib.h>

TransHelp::TransHelp(int n)	
{
	cout << "Car was created" << endl;
}

TransHelp::~TransHelp()
{
	cout << "Car was destroyed" << endl;
}

int TransHelp::getGasolineStatus(void)
{
	return 0;
	// TODO : implement
}


void TransHelp::setGasolineStatus(int GasolineAmount)
{
	// TODO : implement
}


int TransHelp::getCarStatus(void)
{
	return 0;
}


void TransHelp::setCarStatus(int Status)
{
	

}


bool TransHelp::isSummerTiers(void)
{
	return 0;
	// TODO : implement
}

int TransHelp::chooseGasolineNeed(void)
{	
	return 0;
	// TODO : implement
}

void TransHelp::changeGasolineStatus(int GasolineAmount, int key)
{

}
int TransHelp::canMove()
{
	return 0;
}
int TransHelp::getRepairCost()
{
	return 0;
}
int TransHelp::getGasCost()
{
	return 0;
}
int TransHelp::getMaxSpeed()
{
	return 0;
}
int TransHelp::consumpedGasoline(int SomeDist)
{
	return 0;
}

