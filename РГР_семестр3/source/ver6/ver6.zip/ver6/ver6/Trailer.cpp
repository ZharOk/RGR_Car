
#include "Trailer.h"

Trailer::Trailer()
{

}
Trailer::Trailer(double mod)
{
	consumption_mod=mod;
}
Trailer::~Trailer()
{

}

