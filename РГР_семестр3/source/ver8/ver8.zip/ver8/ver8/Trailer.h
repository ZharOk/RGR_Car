#include <iostream>
using namespace std;

///@brief Class Trailer. Empty Class.
class Trailer
{
public:
	Trailer();
	Trailer(double);
	~Trailer();
private:

    double consumption_mod;

};