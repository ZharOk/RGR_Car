#include "Error.h"
#include <iostream>
#include <conio.h>
using namespace std;

void Error::setDefault()
{  cout << "Error!" <<endl;                                                              
  }