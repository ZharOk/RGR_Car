///@brief Class Error, handles Error 's
class Error
{
	                  					          								    
public:
	///@brief Constructor of Error.
  Error() { } 
  ///@brief Destructor of Error.
  ~Error() { }
  ///@brief Message of Error.
  void setDefault(); 

};

