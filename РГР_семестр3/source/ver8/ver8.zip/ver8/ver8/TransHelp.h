#ifndef TRANSHELP
#define TRANSHELP

#include <iostream>
#include "Trailer.h"
using namespace std;

///@brief Class Trailer.
class Trailer;

///@brief Class TransHelp.
class TransHelp
{
	public:
    ///@brief Constructor of TransHelp.
	TransHelp(int n);
	///@brief Contructor of copy TransHelp.
	TransHelp(TransHelp& TransHelpCopy);
	///@brief Distructor of TransHelp.
	~TransHelp();
	///@brief Get Gasoline Status.
	int getGasolineStatus(void) const;
	///@brief Set Gasoline station.
	void setGasolineStatus(int GasolineAmount);
	///@brief Change Gasoline Station.
	void changeGasolineStatus(int GasolineAmount, int key);
	///@brief Get Car Status.
	int getCarStatus(void) const;
	///@brief Get Car Status.
	void setCarStatus(int Status);
	///@brief Set sumer tires on the TransHelp
	bool isSummerTiers(void);
	///@brief Choose Gasoline need.
	int chooseGasolineNeed(void);
	///@brief Get gas prise
	int getGasCost(void);
	///@brief Get repair Cost.
	int getRepairCost();
	///@brief Metod return can car move or no.
	int canMove();
	///@brief Get max speed.
	int getMaxSpeed() const;
	///@brief Consumped Gasoline.
	int consumpedGasoline(int SomeDist);
   
protected:
	int maxSpeed;
	int maxGasoline;
private:
	int GasolineStatus;
	int carStatus;
	bool areSummerTiers;
	int GasolineConsumption;
	int GasolineNeed;
	int repairCost;
	int repairLevel;
	int gasCost;


};

class AnotherCar: public TransHelp
{
public:
	AnotherCar(int n, bool main):TransHelp(n)
	{
		mainCar=main;
	}
	~AnotherCar();
	void setMaxSpeed(int);
	void setMaxGasoline(int);
	bool isMainCar();
private:
	bool mainCar;

};
class Motorcycle:public TransHelp
{
public:
	Motorcycle(int n, int amount, bool carr):TransHelp(n)
	{
		amountWheels=amount;
		withCarriage=carr;
	}
	~Motorcycle();
	void setMaxSpeed(int);
	void setmaxGasoline(int);
	int getAmountWheels() const;
	bool isCarriage();
private:
	int amountWheels;
	bool withCarriage;
};
class Quadrocycle:public  Motorcycle, public AnotherCar
{
public:
	Quadrocycle(int n, int amount, bool carr, bool main):Motorcycle(n, amount, carr), AnotherCar(n, main)
	{

	}
	~Quadrocycle();
private:

};

class TrailerCar:public AnotherCar, public Trailer
{
};

#endif